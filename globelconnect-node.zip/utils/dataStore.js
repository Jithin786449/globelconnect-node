/*
 * Simple in-memory datastore for plans.
 *
 * The application does not persist data between restarts; if you need a
 * persistent store use a database such as PostgreSQL or SQLite.  This
 * module centralises access to the plans cache so that scheduled jobs and
 * route handlers can share the same state.
 */

let plans = [];

export function getPlans() {
  return plans;
}

export function setPlans(list) {
  plans = Array.isArray(list) ? list : [];
}