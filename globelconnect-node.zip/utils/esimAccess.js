import axios from 'axios';

/*
 * Wrapper around the eSIM Access partner API.
 *
 * The eSIM Access API uses an AccessCode and SecretKey for authentication.
 * These values **must** come from your `.env` file and should never be
 * committed to version control.  Each request includes the following headers:
 *
 *   RT-AccessCode: <access code>
 *   RT-SecretKey:  <secret key>
 *
 * See the official documentation for details and the latest endpoint list.
 */

const baseURL = process.env.ESIM_BASE_URL || 'https://api.esimaccess.com';
const accessCode = process.env.ESIM_ACCESS_CODE;
const secretKey = process.env.ESIM_SECRET_KEY;

// Create an Axios instance with base configuration
const client = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
    'RT-AccessCode': accessCode,
    'RT-SecretKey': secretKey,
  },
  timeout: 15000,
});

/**
 * Fetch all available data packages (plans).
 *
 * @param {Object} options - Filtering options (locationCode, type, packageCode, slug, iccid)
 * @returns {Promise<Array>} A list of package objects
 */
export async function listPackages(options = {}) {
  try {
    const res = await client.post('/api/v1/open/package/list', options);
    if (res.data && res.data.obj && Array.isArray(res.data.obj.packageList)) {
      return res.data.obj.packageList;
    }
    return [];
  } catch (err) {
    console.error('Error fetching packages:', err.message);
    return [];
  }
}

/**
 * Create an order for one or more eSIM packages.
 *
 * @param {Object} params
 * @param {string} params.transactionId - Unique transaction ID for the order
 * @param {Array} params.packageInfoList - List of { packageCode, count, price?, periodNum? }
 * @param {number} [params.amount] - Optional total amount (price * count)
 * @returns {Promise<Object>} The order response containing orderNo and transactionId
 */
export async function orderProfiles({ transactionId, packageInfoList, amount }) {
  try {
    const body = { transactionId, packageInfoList };
    if (amount) body.amount = amount;
    const res = await client.post('/api/v1/open/esim/order', body);
    return res.data;
  } catch (err) {
    console.error('Error ordering profiles:', err.message);
    return { success: false, errorMsg: err.message };
  }
}

/**
 * Query all allocated eSIM profiles for a given order or transaction.
 *
 * Provide either orderNo, esImTranNo or a combination of startTime/endTime for a bulk query.
 * @param {Object} params
 * @returns {Promise<Object>} A list of eSIMs and their details
 */
export async function queryAllocatedProfiles(params) {
  try {
    const res = await client.post('/api/v1/open/esim/query', params);
    return res.data;
  } catch (err) {
    console.error('Error querying profiles:', err.message);
    return { success: false, errorMsg: err.message };
  }
}

/**
 * Cancel an unused eSIM profile, returning its value to your account balance.
 * @param {Object} params { iccid?, esimTranNo? }
 * @returns {Promise<Object>} API response
 */
export async function cancelProfile(params) {
  try {
    const res = await client.post('/api/v1/open/esim/cancel', params);
    return res.data;
  } catch (err) {
    console.error('Error cancelling profile:', err.message);
    return { success: false, errorMsg: err.message };
  }
}

/**
 * Query the merchant account balance.
 * @returns {Promise<number|null>} The balance as returned by the API, or null on failure
 */
export async function getBalance() {
  try {
    const res = await client.post('/api/v1/open/balance/query');
    if (res.data && res.data.obj && typeof res.data.obj.balance === 'number') {
      return res.data.obj.balance;
    }
    return null;
  } catch (err) {
    console.error('Error querying balance:', err.message);
    return null;
  }
}

/**
 * Fetch a list of supported regions and countries.
 * @returns {Promise<Array>} List of region objects
 */
export async function listSupportedRegions() {
  try {
    const res = await client.post('/api/v1/open/location/list', {});
    if (res.data && res.data.obj && Array.isArray(res.data.obj.locationList)) {
      return res.data.obj.locationList;
    }
    return [];
  } catch (err) {
    console.error('Error fetching regions:', err.message);
    return [];
  }
}

/**
 * Convert price integer from API to a floating point with 2 decimals.
 * Many API fields return price as an integer representing cents (e.g. 10000 = 100.00).
 *
 * @param {number|string} priceInt
 * @returns {string} Formatted price (e.g. "100.00")
 */
export function formatPrice(priceInt) {
  const value = typeof priceInt === 'string' ? parseFloat(priceInt) : priceInt;
  return (value / 100).toFixed(2);
}