import express from 'express';
import { listPackages, formatPrice } from '../utils/esimAccess.js';
import { getPlans, setPlans } from '../utils/dataStore.js';

async function fetchPlans() {
  const current = getPlans();
  if (current.length > 0) return current;
  const fresh = await listPackages();
  setPlans(fresh);
  return fresh;
}

export default function pagesRouter() {
  const router = express.Router();

  // Home/Landing page
  router.get('/', async (req, res) => {
    // Show a few popular plans on the homepage
    const plans = await fetchPlans();
    const samplePlans = plans.slice(0, 4).map((pkg) => ({
      code: pkg.packageCode,
      name: pkg.name,
      price: formatPrice(pkg.price),
      dataGb: pkg.dataGb || pkg.dataGB || pkg.data || null,
      validityDays: pkg.validityDays || pkg.validity || null,
    }));
    res.render('index', { samplePlans });
  });

  // Plans listing page
  router.get('/plans', async (req, res) => {
    const plans = await fetchPlans();
    // Transform plans for display
    const displayPlans = plans.map((pkg) => ({
      code: pkg.packageCode,
      name: pkg.name,
      price: formatPrice(pkg.price),
      dataGb: pkg.dataGb || pkg.dataGB || pkg.data || null,
      validityDays: pkg.validityDays || pkg.validity || null,
    }));
    res.render('plans', { plans: displayPlans });
  });

  // Individual plan page
  router.get('/plans/:code', async (req, res) => {
    const { code } = req.params;
    const plans = await fetchPlans();
    const plan = plans.find((p) => p.packageCode === code);
    if (!plan) {
      return res.status(404).render('error', { message: 'Plan not found' });
    }
    const detail = {
      code: plan.packageCode,
      name: plan.name,
      description: plan.description || '',
      price: formatPrice(plan.price),
      dataGb: plan.dataGb || plan.dataGB || plan.data || null,
      validityDays: plan.validityDays || plan.validity || null,
    };
    res.render('plan', { plan: detail });
  });

  // How it works page
  router.get('/how-it-works', (req, res) => {
    res.render('how');
  });

  // Contact page
  router.get('/contact', (req, res) => {
    res.render('contact');
  });

  // Terms and conditions
  router.get('/terms', (req, res) => {
    res.render('terms');
  });

  // Privacy policy
  router.get('/privacy', (req, res) => {
    res.render('privacy');
  });

  return router;
}